package com.samiun.mynews.adapter

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.navigation.NavController
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.samiun.mynews.Constant
import com.samiun.mynews.NewsFragment
import com.samiun.mynews.ui.HomeFragmentDirections

class ViewpagerAdapter(fragmentManager: FragmentManager, lifecycle: Lifecycle, private val navController: NavController): FragmentStateAdapter(fragmentManager,lifecycle){
    //val findNavcontroller
    override fun getItemCount(): Int {
    return 5
    }

    override fun createFragment(position: Int): Fragment {
        val fragment = NewsFragment()
        val args = Bundle()
       return when(position){
           0->{

               args.putString("type", Constant.topnews)
               fragment.arguments = args
               return fragment


           }
           1-> {
               args.putString("type", Constant.sports)
               fragment.arguments = args
               return fragment
           }
           2->{
               args.putString("type", Constant.entertainment)
               fragment.arguments = args
               return fragment
           }

           3->{
               args.putString("type", Constant.technews)
               fragment.arguments = args
               return fragment
           }

           else ->{
               args.putString("type", Constant.business)
               fragment.arguments = args
               return fragment
           }

       }
    }

}
