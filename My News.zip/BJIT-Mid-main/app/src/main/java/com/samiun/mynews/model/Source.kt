package com.samiun.mynews.model

data class Source(
    val id: String?,
    val name: String?
)