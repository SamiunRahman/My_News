package com.samiun.mynews.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.google.android.material.tabs.TabLayoutMediator
import com.samiun.mynews.Constant
import com.samiun.mynews.adapter.ViewpagerAdapter
import com.samiun.mynews.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var navController: NavController


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        navController = findNavController()
        return binding.root
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val tabLayout = binding.tabLayout
        val viewpage = binding.viewPager2
        val tabAdapter = ViewpagerAdapter(childFragmentManager, lifecycle, navController)
        viewpage.adapter = tabAdapter
        TabLayoutMediator(tabLayout, viewpage) { tab, position ->
            when (position) {
                0 -> {
                    tab.text = Constant.topnews
                }
                1 -> {
                    tab.text = Constant.sports
                }
                2 -> {
                    tab.text = Constant.entertainment
                }
                3-> {
                    tab.text = Constant.technews
                }
                else -> {
                    tab.text = Constant.business
                }
            }
        }.attach()
    }
}