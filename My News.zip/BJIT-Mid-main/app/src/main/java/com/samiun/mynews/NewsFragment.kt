package com.samiun.mynews

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.appcompat.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.RecyclerView
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.material.snackbar.Snackbar
import com.samiun.mynews.adapter.NewsAdapter
import com.samiun.mynews.data.ArticleEntity
import com.samiun.mynews.databinding.FragmentNewsBinding
import com.samiun.mynews.network.GetArticlesWorker
import com.samiun.mynews.network.overview.OverviewViewModel
import java.util.concurrent.TimeUnit


class NewsFragment() : Fragment() {
    val gerArgs : NewsFragmentArgs by navArgs()


    lateinit var newsList : List<ArticleEntity>

    private lateinit var viewModel: OverviewViewModel
    private lateinit var recyclerView: RecyclerView

    // This property is only valid between onCreateView and
    // onDestroyView
    private var _binding: FragmentNewsBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentNewsBinding.inflate(inflater)
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        // Giving the binding access to the OverviewViewModel
        viewModel = ViewModelProvider(this)[OverviewViewModel::class.java]
        //binding.viewModel = viewModel

        val work = PeriodicWorkRequestBuilder<GetArticlesWorker>(10, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(requireContext()).enqueue(work)

        recyclerView = binding.newsArticle
        val type = gerArgs.type
        Log.d("News Fragment", "onViewCreated: $type")

        if(type== Constant.topnews){
            viewModel.readTonewspArticle.observe(viewLifecycleOwner) {
                recyclerView.adapter = NewsAdapter(requireContext(), viewModel, it)
                newsList = it

            }
        }
        else if(type== Constant.business){
            viewModel.readBusinessArticle.observe(viewLifecycleOwner) {
                newsList = it
                recyclerView.adapter = NewsAdapter(requireContext(), viewModel, it)

            }
        }

        else if(type== Constant.entertainment){
            viewModel.readEntertainemtArticle.observe(viewLifecycleOwner) {
                newsList = it
                recyclerView.adapter = NewsAdapter(requireContext(), viewModel, it)

            }
        }

        else if(type== Constant.technews){
            viewModel.readTechArticle.observe(viewLifecycleOwner) {
                newsList = it
                recyclerView.adapter = NewsAdapter(requireContext(), viewModel, it)

            }
        }

        else if(type== Constant.sports){
            viewModel.readsportsArticle.observe(viewLifecycleOwner) {
                newsList = it
                recyclerView.adapter = NewsAdapter(requireContext(), viewModel, it)

            }
        }

        else{
            viewModel.readAllArticle.observe(viewLifecycleOwner) {
                newsList = it
                recyclerView.adapter = NewsAdapter(requireContext(), viewModel, it)

            }
        }

        binding.refreshBtn.setOnClickListener{
            getArticles()
        }
        binding.swipeToRefresh.setOnRefreshListener {
            getArticles()
            binding.swipeToRefresh.isRefreshing = false
        }

    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


    // API Call to get Articles in Room
    fun getArticles(){
        if(isOnline(requireContext())){
            viewModel.getTopNewsArticles()
           Snackbar.make(binding.newsArticle, "Article List updated! 👌", Snackbar.LENGTH_SHORT).show()
        }
        else{
            Snackbar.make(binding.newsArticle, "Require Internet to refresh article! 😒", Snackbar.LENGTH_SHORT).show()
        }
    }

    fun getArticlesBackGround(){
        viewModel.getTopNewsArticles()
        Log.d("Get Article worker", "Getting articles")

    }

    fun isOnline(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (connectivityManager != null) {
            val capabilities =
                connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
            if (capabilities != null) {
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                    Log.i("Internet", "NetworkCapabilities.TRANSPORT_CELLULAR")
                    return true
                } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    Log.i("Internet", "NetworkCapabilities.TRANSPORT_WIFI")
                    return true
                } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                    Log.i("Internet", "NetworkCapabilities.TRANSPORT_ETHERNET")
                    return true
                }
            }
        }
        Toast.makeText(requireContext(), "Sorry, Internet Access is required to get news!", Toast.LENGTH_SHORT).show()
        return false
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.top_menu, menu)
        val item = menu?.findItem(R.id.action_search_btn)
        val searchview = item?.actionView as SearchView
        searchview.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }
            override fun onQueryTextChange(newText: String): Boolean {
                if (recyclerView.adapter != null) {
                    val newsAdapter = recyclerView.adapter as NewsAdapter
                    //newsAdapter.filter(newText)
                    if(newText.length>2){
                        newsAdapter.filter(newText)
                    }
                    else newsAdapter.updateList(newsList)
                }
                return true
            }
        })
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        when(id){
            R.id.action_search_btn ->{
                Toast.makeText(requireContext(), "${requireContext()}", Toast.LENGTH_SHORT).show()
                return true
            }
            R.id.action_change_View ->{
                Toast.makeText(requireContext(), "View Changed ", Toast.LENGTH_SHORT).show()
                return true
            }
        }
        return false
    }
}