package com.samiun.mynews.network

import android.content.Context
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.samiun.mynews.NewsFragment

class GetArticlesWorker(appContext: Context, workerParams: WorkerParameters) : Worker(appContext, workerParams) {
    override fun doWork(): Result {
        val newsFragment = NewsFragment()
        newsFragment.getArticlesBackGround()
        Log.d("Get Articles Background ", "Get Article Called ")
        return Result.success()
    }
}
