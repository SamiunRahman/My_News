package com.samiun.mynews.network

import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import com.samiun.mynews.Constant.Companion.BASE_URL
import com.samiun.mynews.Constant.Companion.BUSINESS_END_POINT
import com.samiun.mynews.Constant.Companion.ENTERTAIMENT_END_POINT
import com.samiun.mynews.Constant.Companion.SPORTS_END_POINT
import com.samiun.mynews.Constant.Companion.TECH_END_POINT
import com.samiun.mynews.Constant.Companion.TOPNEWS_END_POINT
import com.samiun.mynews.model.News
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET

private val moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()

private val retrofit = Retrofit.Builder()
    .addConverterFactory(MoshiConverterFactory.create(moshi))
    .baseUrl(BASE_URL)
    .build()

interface NewsApiService{

    @GET(TOPNEWS_END_POINT)
    suspend fun getTopArticales(): News

    @GET(TECH_END_POINT)
    suspend fun getTechArticles(): News

    @GET(ENTERTAIMENT_END_POINT)
    suspend fun getEntertainmentArticles(): News

    @GET(BUSINESS_END_POINT)
    suspend fun getBusinessArticles(): News

    @GET(SPORTS_END_POINT)
    suspend fun getSportsArticles(): News


}

object  NewsApi {
    val retrofitService : NewsApiService by lazy { retrofit.create(NewsApiService::class.java) }
}