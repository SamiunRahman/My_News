package com.samiun.mynews.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.samiun.mynews.Constant

@Dao
interface ArticleDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addAllArticle(articleEntity: List<ArticleEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addBookmark(articleBookmark: ArticleBookmark)

    @Query("DELETE FROM article_table")
    suspend fun deleteAll()

    @Query("select * from article_table order by id desc")
     fun readAllArticle(): LiveData<List<ArticleEntity>>

    @Query("select * from article_table where type = \"Top News\" order by id desc")
    fun readTopnewsArticle(): LiveData<List<ArticleEntity>>

    @Query("select * from article_table where type = \"BBC News\" order by id desc")
    fun readBbcnewsArticle(): LiveData<List<ArticleEntity>>

    @Query("select * from article_table where type = \"Entertainment\" order by id desc")
    fun readEntertainmentArticle(): LiveData<List<ArticleEntity>>

    @Query("select * from bookmark_table order by id")
     fun readAllBookmarked(): LiveData<List<ArticleBookmark>>

    @Update
    suspend fun updateArticle(articleEntity: ArticleEntity)




    @Query("Update article_table set bookmark= false where id= :id")
    suspend fun updateArticleBookmark(id: Int)
    @Delete
    suspend fun deleteBookmark(articleBookmark: ArticleBookmark)

    @Query("select * from article_table where type = :type order by id desc")
    fun readTypeddata(type: String): LiveData<List<ArticleEntity>>
}
