package com.samiun.mynews.adapter

import android.content.Context
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.samiun.mynews.R
import com.samiun.mynews.data.ArticleBookmark
import com.samiun.mynews.data.ArticleEntity
import com.samiun.mynews.network.overview.OverviewViewModel
import com.samiun.mynews.ui.HomeFragmentDirections
import java.util.*

class BookmarkAdapter(private val context: Context, private val viewModel: OverviewViewModel, private var arrayList:List<ArticleBookmark>): RecyclerView.Adapter<BookmarkAdapter.NewsViewHolder>(){

    class NewsViewHolder(private var binding: View
    ): RecyclerView.ViewHolder(binding){

        val image=itemView.findViewById<ImageView>(R.id.news_image)
        val title=itemView.findViewById<TextView>(R.id.news_title)
        val description=itemView.findViewById<TextView>(R.id.news_content)
        val bookmarkBtn = itemView.findViewById<ImageView>(R.id.bookmark)
        val item_list = itemView.findViewById<ConstraintLayout>(R.id.constraint_item)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsViewHolder {
        val root= LayoutInflater.from(parent.context).inflate(R.layout.news_list, parent,false)
        return NewsViewHolder(root)
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) {
        val news=arrayList[position]
        val url = news.urlToImage

        if (!TextUtils.isEmpty(news.title)){
            holder.title.text=news.title
        }else{
            holder.title.text= "No title"
        }

        if (!TextUtils.isEmpty(news.title)){
            holder.description.text=news.description
        }else{
            holder.description.text="news.description"
        }

        holder.bookmarkBtn.setImageResource(R.drawable.bookmarked)



        holder.item_list.setOnClickListener {
            val article = ArticleEntity(news.id,"Bookmarked Article",true,news.author,news.content,news.description,news.publishedAt,news.title,news.url,news.urlToImage)
            val action = HomeFragmentDirections.actionHomeFragmentToDetailArticleFragment(article)
            holder.itemView.findNavController().navigate(action)
            Toast.makeText(context, "Title CLicked", Toast.LENGTH_SHORT).show()
        }

        holder.bookmarkBtn.setOnClickListener {

            viewModel.deleteBookmark(arrayList[position])
            Toast.makeText(context, "Updated to : ${news.id}", Toast.LENGTH_SHORT).show()


        }


        Log.v("News Adapter ", "${news.urlToImage}")


        Glide
            .with(context)
            .load(url)
            .placeholder(R.drawable.ic_baseline_downloading_24)
            .error(R.drawable.ic_baseline_broken_image_24)
            .into(holder.image)
    }

    override fun getItemCount(): Int {
        Log.d("Adapter News", "getItemCount: ${arrayList.size} ")
        return  arrayList.size
    }

    fun filter(query: String) {
        val filteredList = ArrayList<ArticleBookmark>()
        for (article in arrayList) {
            if (article.title?.lowercase(Locale.ROOT)?.contains(query.lowercase(Locale.ROOT)) == true) {
                filteredList.add(article)
            }
        }
        updateList(filteredList)
    }
    fun updateList(list: List<ArticleBookmark>) {
        arrayList = list
        notifyDataSetChanged()
    }


}