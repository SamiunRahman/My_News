package com.samiun.mynews.network.overview

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import com.samiun.mynews.Constant
import com.samiun.mynews.data.ArticleBookmark
import com.samiun.mynews.data.ArticleDatabase
import com.samiun.mynews.data.ArticleEntity
import com.samiun.mynews.model.Article
import com.samiun.mynews.network.NewsApi
import com.samiun.mynews.data.ArticleRepository
import com.samiun.mynews.NewsFragment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class OverviewViewModel(application: Application): AndroidViewModel(application) {
    val readAllArticle: LiveData<List<ArticleEntity>>

    val readTonewspArticle: LiveData<List<ArticleEntity>>
    val readBusinessArticle: LiveData<List<ArticleEntity>>
    val readEntertainemtArticle: LiveData<List<ArticleEntity>>
    val readTechArticle: LiveData<List<ArticleEntity>>
    val readsportsArticle: LiveData<List<ArticleEntity>>
    val readAllBookmark: LiveData<List<ArticleBookmark>>
    private val _articles= MutableLiveData<List<Article>>()
    val articles : LiveData<List<Article>> = _articles
    private val _articlesEntity= MutableLiveData<List<ArticleEntity>>()
    val articlesEntity : LiveData<List<ArticleEntity>> = _articlesEntity
    private val repository : ArticleRepository

    init {
        val articleDao = ArticleDatabase.getDatabase(application).articleDao()
        repository = ArticleRepository(articleDao)
        readAllArticle = repository.readAllArticle
//        readTonewspArticle = repository.readTopnewsArticle
//        readBbcArticle = repository.readBbcnewsArticle
//        readEntertainemtArticle = repository.readAEntertainmentArticle

        readTonewspArticle = repository.readTypeArticles(Constant.topnews)
        readBusinessArticle = repository.readTypeArticles(Constant.business)
        readEntertainemtArticle = repository.readTypeArticles(Constant.entertainment)
        readsportsArticle = repository.readTypeArticles(Constant.sports)
        readTechArticle = repository.readTypeArticles(Constant.technews)
        readAllBookmark = repository.readAllBookmark

    }

     fun getTopNewsArticles(){
        viewModelScope.launch {
            try {

                Log.d("OverviewFragment", "Loading Data")
                _articles.value = NewsApi.retrofitService.getTopArticales().articles
                _articlesEntity.value= articles.value?.let {
                    convertToArticleEntityList(it,Constant.topnews)

                }
                deleteArticles()
                articlesEntity.value?.let { addArticleList(it) }


                _articles.value = NewsApi.retrofitService.getBusinessArticles().articles
                _articlesEntity.value= articles.value?.let {
                    convertToArticleEntityList(it,Constant.business)
                }
                articlesEntity.value?.let { addArticleList(it) }


                _articles.value = NewsApi.retrofitService.getEntertainmentArticles().articles
                _articlesEntity.value= articles.value?.let {
                    convertToArticleEntityList(it,Constant.entertainment)
                }
                articlesEntity.value?.let { addArticleList(it) }


                _articles.value = NewsApi.retrofitService.getSportsArticles().articles
                _articlesEntity.value= articles.value?.let {
                    convertToArticleEntityList(it,Constant.sports)
                }
                articlesEntity.value?.let { addArticleList(it) }


                _articles.value = NewsApi.retrofitService.getTechArticles().articles
                _articlesEntity.value= articles.value?.let {
                    convertToArticleEntityList(it,Constant.technews)
                }
                articlesEntity.value?.let { addArticleList(it) }

                Log.d("OverviewViewModel", "getNewsArticles: ${articlesEntity.value?.get(0)?.url}")
            }
            catch (e: java.lang.Exception){
                _articles.value = listOf()
            }
        }
    }

    fun convertToArticleEntityList(articles: List<Article>, string: String): List<ArticleEntity> {
        return articles.map { article ->
            ArticleEntity(
                0,
                string,
                false,
                article.author,
                article.content,
                article.description,
                article.publishedAt,
                //article.source,
                article.title,
                article.url,
                article.urlToImage
            )
        }
    }

    fun addArticleList(articleEntity: List<ArticleEntity>){
        viewModelScope.launch (Dispatchers.IO){
            repository.addArticle(articleEntity)
        }
    }


    fun deleteArticles(){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAllArticle()
        }
    }



    fun addBookmark(articleBookmark: ArticleBookmark){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addArticleBookmark(articleBookmark)
        }
    }

    fun updateArticle(articleEntity: ArticleEntity){
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateArticleEntity(articleEntity)
        }
    }

    fun deleteBookmark(articleBookmark: ArticleBookmark){
        viewModelScope.launch(Dispatchers.IO) {
            updateArticleBookmark(articleBookmark.id)
            repository.delete(articleBookmark)
        }
    }

    fun updateArticleBookmark(id: Int){
        viewModelScope.launch(Dispatchers.IO){
            repository.updateArticleBookmark(id)
        }
    }

    fun addRemoveBookmark(articleEntity: ArticleEntity){
        try{
            if (articleEntity.bookmark){
                articleEntity.bookmark=false
                val bookMark = ArticleBookmark(articleEntity.id,articleEntity.author,articleEntity.content,articleEntity.description,articleEntity.publishedAt,articleEntity.title,articleEntity.url,articleEntity.urlToImage)
                deleteBookmark(bookMark)
                updateArticle(articleEntity)
            }
            else{
                articleEntity.bookmark=true
                updateArticle(articleEntity)
                val bookMark = ArticleBookmark(articleEntity.id,articleEntity.author,articleEntity.content,articleEntity.description,articleEntity.publishedAt,articleEntity.title,articleEntity.url,articleEntity.urlToImage)
                addBookmark(bookMark)
            }
        }
        catch(_: java.lang.Exception) {
        }
    }

}