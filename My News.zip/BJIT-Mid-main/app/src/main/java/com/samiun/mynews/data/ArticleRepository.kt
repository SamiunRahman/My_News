package com.samiun.mynews.data

import androidx.lifecycle.LiveData
import com.samiun.mynews.model.Article

class ArticleRepository(private val articleDao: ArticleDao) {
    val readAllArticle: LiveData<List<ArticleEntity>> = articleDao.readAllArticle()
    val readTopnewsArticle: LiveData<List<ArticleEntity>> = articleDao.readTopnewsArticle()
    val readBbcnewsArticle: LiveData<List<ArticleEntity>> = articleDao.readBbcnewsArticle()
    val readAEntertainmentArticle: LiveData<List<ArticleEntity>> = articleDao.readEntertainmentArticle()


    val readAllBookmark: LiveData<List<ArticleBookmark>> = articleDao.readAllBookmarked()

    fun readTypeArticles(type: String): LiveData<List<ArticleEntity>>{
        return articleDao.readTypeddata(type)
    }

    suspend fun addArticle(articleEntityList: List<ArticleEntity>){
        articleDao.addAllArticle(articleEntityList)
    }

    suspend fun deleteAllArticle(){
        articleDao.deleteAll()
    }

    suspend fun addArticleBookmark(articleBookmark: ArticleBookmark){
        articleDao.addBookmark(articleBookmark)
    }

    suspend fun updateArticleEntity(articleEntity: ArticleEntity){
        articleDao.updateArticle(articleEntity)
    }

    suspend fun delete(articleBookmark: ArticleBookmark) {
        articleDao.deleteBookmark(articleBookmark)
    }
    suspend fun updateArticleBookmark(id: Int){
        articleDao.updateArticleBookmark(id)
    }


}