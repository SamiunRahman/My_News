package com.samiun.mynews

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.samiun.mynews.data.ArticleEntity
import com.samiun.mynews.databinding.FragmentDetailArticleBinding
import java.text.SimpleDateFormat
import java.util.*
import kotlin.reflect.jvm.internal.impl.metadata.ProtoBuf.Type.Argument

class DetailArticleFragment : Fragment() {
    private val navArgs by navArgs<DetailArticleFragmentArgs>()
    private var _binding : FragmentDetailArticleBinding?= null
    val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentDetailArticleBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val article:String ?=navArgs.article.publishedAt
        val getArticle = navArgs.article
        Log.d("TAG", "onViewCreated:$article ")




        Glide
            .with(requireActivity())
            .load(getArticle?.urlToImage)
            .placeholder(R.drawable.ic_baseline_downloading_24)
            .error(R.drawable.ic_baseline_broken_image_24)
            .into(binding.imageUrl)
        binding.timeTv.text= getArticle?.publishedAt?.let { dateFormat(it) }
        binding.descriptionTv.text = getArticle?.description
        binding.titleTv.text = getArticle?.title
        binding.authorTv.text = getArticle?.author
        binding.categoryTv.text = getArticle?.type
        binding.contentTv.text =getArticle?.content

        binding.readBtn.setOnClickListener {
            val action = getArticle.url?.let { it1 ->
                DetailArticleFragmentDirections.actionDetailArticleFragmentToWebFragment(it1)
            }
            if (action != null) {
                findNavController().navigate(action)
            }
        }


    }

    fun dateFormat(date: String): String{

        val dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'"
        if(date.length ==dateFormat.length){
            return ""
        }
        val sdf = SimpleDateFormat(dateFormat, Locale.getDefault())
        val inputTime = sdf.parse(date).time
        val currentTime = System.currentTimeMillis()
        val difference = currentTime - inputTime
        val hoursAgo = (difference / (1000 * 60 * 60)).toInt()
        val daysAgo = (difference / (1000 * 60 * 60*24)).toInt()

        if (hoursAgo<25){
            return ("$hoursAgo hours ago.")
        }
        else{
            return ("$daysAgo days ago")
        }
    }

    val menu = R.menu.bottom_nav_menu

}
