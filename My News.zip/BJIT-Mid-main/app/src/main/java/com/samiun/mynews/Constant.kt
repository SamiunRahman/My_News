package com.samiun.mynews

class Constant {
    companion object{
        const val BASE_URL =
            "https://newsapi.org"
        const val apikey = "apiKey=158e738d4a6447db8c51dbbb7d79d7b1"
        //private const val apikey = "apiKey=e5e302420f17410aad045d2de57868cf"

        private const val topnewstype= "v2/top-headlines?country=us&"
        const val TOPNEWS_END_POINT = "$topnewstype$apikey"
        const val topnews = "Top News"

        private const val techtype = "v2/top-headlines?language=en&category=technology&"
        const val TECH_END_POINT = "$techtype$apikey"
        const val technews = "Technology"

        private const val businessType = "/v2/top-headlines?language=en&category=business&"
        const val BUSINESS_END_POINT = "$businessType$apikey"
        const val business = "Business"


        private const val sportstType = "v2/top-headlines?language=en&category=sports&"
        const val SPORTS_END_POINT = "$sportstType$apikey"
        const val sports = "Sports"

        private const val entertanmentType = "v2/top-headlines?language=en&category=entertainment&"
        const val ENTERTAIMENT_END_POINT = "$entertanmentType$apikey"
        const val entertainment = "Entertainment"

    }
}