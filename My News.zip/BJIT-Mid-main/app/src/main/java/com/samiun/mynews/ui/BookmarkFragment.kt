package com.samiun.mynews.ui

import android.os.Bundle
import android.view.*
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.samiun.mynews.Constant
import com.samiun.mynews.R
import com.samiun.mynews.adapter.BookmarkAdapter
import com.samiun.mynews.adapter.NewsAdapter
import com.samiun.mynews.data.ArticleBookmark
import com.samiun.mynews.databinding.FragmentBookmarkBinding
import com.samiun.mynews.databinding.FragmentNewsBinding
import com.samiun.mynews.network.overview.OverviewViewModel

class BookmarkFragment : Fragment() {
    private lateinit var viewModel: OverviewViewModel
    lateinit var bookmarkList : List<ArticleBookmark>
    private lateinit var recyclerView: RecyclerView
    private var _binding: FragmentBookmarkBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val binding = FragmentBookmarkBinding.inflate(inflater)
        // Allows Data Binding to Observe LiveData with the lifecycle of this Fragment
        //binding.lifecycleOwner = this
        // Giving the binding access to the OverviewViewModel


        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[OverviewViewModel::class.java]
        binding.viewModel = viewModel

        recyclerView = binding.bookmarkArticle
        viewModel.readAllBookmark.observe(viewLifecycleOwner, Observer {
            bookmarkList = it
            binding.bookmarkArticle.adapter = BookmarkAdapter(requireContext(), viewModel, it)

        })
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.top_menu, menu)
        val item = menu?.findItem(R.id.action_search_btn)
        val searchview = item?.actionView as SearchView
        searchview.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }
            override fun onQueryTextChange(newText: String): Boolean {
                if (recyclerView.adapter != null) {
                    val bookmarkApadter = recyclerView.adapter as BookmarkAdapter
                    //newsAdapter.filter(newText)
                    if(newText.length>2){
                        bookmarkApadter.filter(newText)
                    }
                    else bookmarkApadter.updateList(bookmarkList)
                }
                return true
            }
        })
        super.onCreateOptionsMenu(menu, inflater)
    }

}